#!/bin/bash

# apt-get installs
echo "apt-get: Installing Qt dependencies..."
apt-get install -y libqt5webkit5 > /dev/null
